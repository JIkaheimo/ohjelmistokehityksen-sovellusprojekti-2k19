/********************************************************************************
** Form generated from reading UI file 'laskunmaksu.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LASKUNMAKSU_H
#define UI_LASKUNMAKSU_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_laskunmaksu
{
public:
    QWidget *centralWidget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QComboBox *comboBox;
    QLabel *label_11;
    QLabel *label_12;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QWidget *widget1;
    QVBoxLayout *verticalLayout;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *laskunmaksu)
    {
        if (laskunmaksu->objectName().isEmpty())
            laskunmaksu->setObjectName(QStringLiteral("laskunmaksu"));
        laskunmaksu->resize(400, 300);
        centralWidget = new QWidget(laskunmaksu);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(140, 200, 85, 27));
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(40, 200, 85, 27));
        comboBox = new QComboBox(centralWidget);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(240, 20, 121, 33));
        label_11 = new QLabel(centralWidget);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(130, 20, 111, 20));
        label_12 = new QLabel(centralWidget);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(290, 130, 54, 17));
        widget = new QWidget(centralWidget);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(40, 50, 90, 134));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout_2->addWidget(label);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QStringLiteral("label_2"));

        verticalLayout_2->addWidget(label_2);

        label_3 = new QLabel(widget);
        label_3->setObjectName(QStringLiteral("label_3"));

        verticalLayout_2->addWidget(label_3);

        label_4 = new QLabel(widget);
        label_4->setObjectName(QStringLiteral("label_4"));

        verticalLayout_2->addWidget(label_4);

        label_5 = new QLabel(widget);
        label_5->setObjectName(QStringLiteral("label_5"));

        verticalLayout_2->addWidget(label_5);

        widget1 = new QWidget(centralWidget);
        widget1->setObjectName(QStringLiteral("widget1"));
        widget1->setGeometry(QRect(150, 50, 58, 134));
        verticalLayout = new QVBoxLayout(widget1);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_6 = new QLabel(widget1);
        label_6->setObjectName(QStringLiteral("label_6"));

        verticalLayout->addWidget(label_6);

        label_7 = new QLabel(widget1);
        label_7->setObjectName(QStringLiteral("label_7"));

        verticalLayout->addWidget(label_7);

        label_8 = new QLabel(widget1);
        label_8->setObjectName(QStringLiteral("label_8"));

        verticalLayout->addWidget(label_8);

        label_9 = new QLabel(widget1);
        label_9->setObjectName(QStringLiteral("label_9"));

        verticalLayout->addWidget(label_9);

        label_10 = new QLabel(widget1);
        label_10->setObjectName(QStringLiteral("label_10"));

        verticalLayout->addWidget(label_10);

        laskunmaksu->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(laskunmaksu);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 400, 27));
        laskunmaksu->setMenuBar(menuBar);
        mainToolBar = new QToolBar(laskunmaksu);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        laskunmaksu->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(laskunmaksu);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        laskunmaksu->setStatusBar(statusBar);

        retranslateUi(laskunmaksu);

        QMetaObject::connectSlotsByName(laskunmaksu);
    } // setupUi

    void retranslateUi(QMainWindow *laskunmaksu)
    {
        laskunmaksu->setWindowTitle(QApplication::translate("laskunmaksu", "laskunmaksu", 0));
        pushButton->setText(QApplication::translate("laskunmaksu", "Hyv\303\244ksy", 0));
        pushButton_2->setText(QApplication::translate("laskunmaksu", "Peruuta", 0));
        label_11->setText(QApplication::translate("laskunmaksu", "Valitse laskun ID:", 0));
        label_12->setText(QApplication::translate("laskunmaksu", "TextLabel", 0));
        label->setText(QApplication::translate("laskunmaksu", "Saajan nimi:", 0));
        label_2->setText(QApplication::translate("laskunmaksu", "Saajan tilinro:", 0));
        label_3->setText(QApplication::translate("laskunmaksu", "Viitenumero:", 0));
        label_4->setText(QApplication::translate("laskunmaksu", "Viesti:", 0));
        label_5->setText(QApplication::translate("laskunmaksu", "Maksun m\303\244\303\244r\303\244:", 0));
        label_6->setText(QApplication::translate("laskunmaksu", "haetaan...", 0));
        label_7->setText(QApplication::translate("laskunmaksu", "haetaan...", 0));
        label_8->setText(QApplication::translate("laskunmaksu", "haetaan...", 0));
        label_9->setText(QApplication::translate("laskunmaksu", "haetaan...", 0));
        label_10->setText(QApplication::translate("laskunmaksu", "haetaan...", 0));
    } // retranslateUi

};

namespace Ui {
    class laskunmaksu: public Ui_laskunmaksu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LASKUNMAKSU_H
