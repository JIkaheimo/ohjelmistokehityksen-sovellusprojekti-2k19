/* UI:n labeleiden nimet joihin pitää setata tietokannasta noudetut laskun tiedot:
 *
 * Saajan nimi: label_6
 * Tilinumero:  label_7
 * Viite:       label_8
 * Viesti:      label_9
 * Maksun määrä: label_10
 */




#include "laskunmaksu.h"
#include "ui_laskunmaksu.h"

laskunmaksu::laskunmaksu(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::laskunmaksu)
{
    ui->setupUi(this);

    ui->comboBox->addItem("aaa");   //Nämä mallina itemssien asettamiseksi comboboxiin,
    ui->comboBox->addItem("bbb");   //korvaa soveltuvalla koodilla joka hakee tietokannasta laskujen ID:t


}

laskunmaksu::~laskunmaksu()
{
    delete ui;
}

void laskunmaksu::on_pushButton_2_clicked()     //Peruutusnapin klikkaus, sulkee tässä ohjelman,
{                                               //pitää lopullisessa versiossa muuttaa sulkemaan vain tämä näkymä?
    qApp->exit();
}

void laskunmaksu::on_pushButton_clicked()       //Hyväksyntänapin klikkaus, emittoi signaalin 'LaskuHyvaksytty', ja
{                                               //asettaa parametriksi valitun laskun ID:n

    QString ID = ui->comboBox->currentText();
    emit LaskuHyvaksytty(ID);

}
