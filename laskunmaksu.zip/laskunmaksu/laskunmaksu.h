#ifndef LASKUNMAKSU_H
#define LASKUNMAKSU_H

#include <QMainWindow>
#include <QMessageBox>
#include <QString>
#include <string>
#include <iostream>

namespace Ui {
class laskunmaksu;
}

class laskunmaksu : public QMainWindow
{
    Q_OBJECT

public:
    explicit laskunmaksu(QWidget *parent = 0);
    ~laskunmaksu();



private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::laskunmaksu *ui;



signals:
    void LaskuHyvaksytty(QString);

};

#endif // LASKUNMAKSU_H
